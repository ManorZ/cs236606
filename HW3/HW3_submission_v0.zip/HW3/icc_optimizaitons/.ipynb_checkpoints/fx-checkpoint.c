#include <stdio.h>


double f(double x){
  double ret;
  ret = 4.0 / (x*x + 1.0);
  return  ret; 
}
